// Package defaults provides recommended configuration values for AWS SDKs and CLIs.
package defaults
