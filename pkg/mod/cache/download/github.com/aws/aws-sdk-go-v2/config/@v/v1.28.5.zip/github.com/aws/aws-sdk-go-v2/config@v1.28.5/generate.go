package config

//go:generate go run -tags codegen ./codegen -output=provider_assert_test.go
//go:generate gofmt -s -w ./
